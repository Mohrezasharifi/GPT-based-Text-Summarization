/* vars */
const form = document.getElementById('form');
const summarizedParagraph = document.getElementById("summarized-article");
const article = document.getElementById('article');
const loader = document.getElementById('loader');
const errorDiv = document.getElementById('error-div');



/* handling form submission */
form.addEventListener('submit', async(e)=>{
    e.preventDefault();
    loader.style.display ='block';
    article.style.display = 'none';
    errorDiv.style.display = 'none';
    const submittedUrl = form.elements['url'].value;
    const encodedURL = encodeURIComponent(submittedUrl);

    const url = `https://article-extractor-and-summarizer.p.rapidapi.com/summarize?url=${encodedURL}&length=3&lang=ar`;
    const options = {
        method: 'GET',
        headers: {
            'X-RapidAPI-Key': '9e8cb64ceamshf1f53bdc2366e3bp154be0jsn8d114f382efe',
            'X-RapidAPI-Host': 'article-extractor-and-summarizer.p.rapidapi.com'
        }
    };

    try {

        const response = await fetch(url, options);
        if (!response.ok) {
          if (response.status === 404) {
            errorDiv.style.display = "block";
            loader.style.display = "none";
            throw new Error("404 Not Found");
          } else if (response.status === 401) {
            errorDiv.style.display = "block";
            loader.style.display = "none";
            throw new Error("401 Unauthorized");
          } else {
            errorDiv.style.display = "block";
            loader.style.display = "none";
            throw new Error(
              `HTTP Error: ${response.status} ${response.statusText}`
            );
          }
        }
        const result = await response.text();
        const parsedResult = JSON.parse(result);
        const summaryText = parsedResult.summary;
        
        summarizedParagraph.innerHTML = summaryText;
        loader.style.display = "none";
        article.style.display = 'flex';

    } catch (error) {
        errorDiv.style.display = 'block';
        console.error(error);
    }
});